FF XIT PANEL - projeto Android nativo

O que este projeto faz:
- Cria uma janela flutuante Android real, sobre outros aplicativos, após autorização do usuário.
- Permite arrastar, recolher/expandir e fechar o painel.
- Os botões ON/OFF controlam apenas estados visuais locais.
- A antena é somente demonstrativa; não detecta jogadores.
- Não lê, altera ou injeta dados no Free Fire.

Como compilar:
1. Abra este projeto em Android Studio ou em um ambiente Android compatível com Gradle.
2. Aguarde a sincronização do Gradle (é necessário internet na primeira compilação).
3. Compile: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. O APK de debug normalmente ficará em app/build/outputs/apk/debug/app-debug.apk.
5. Instale no Moto G15, abra o app e toque em ATIVAR PAINEL FLUTUANTE.
6. Nas configurações do Android, permita "Exibir sobre outros apps" para FF XIT PANEL.
7. Volte ao app e ative o painel.

Observações:
- A primeira compilação requer Android SDK 35 e JDK 17.
- O projeto usa foreground service do tipo specialUse para manter a sobreposição.
- O Android pode mostrar uma notificação persistente enquanto o painel estiver ativo.
- A interface pode variar conforme a versão/ROM do Android.
