package com.example.ffxitpanel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var collapsed = false
    private val channelId = "ffxit_overlay"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        createNotification()
        startForeground(7, notification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun createNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "FF XIT Panel", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId)
                      else Notification.Builder(this)
        return builder.setContentTitle("FF XIT PANEL ativo")
            .setContentText("Painel flutuante em execução")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
    }

    private fun params(): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            dp(230), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(140) }
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(0xF0161616.toInt())
        }
        val header = TextView(this).apply {
            text = "FF XIT  •  ≡"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFFFF4650.toInt())
            setPadding(dp(4), dp(4), dp(4), dp(12))
        }
        // Arraste o painel pelo cabeçalho.
        header.setOnTouchListener(DragTouchListener())
        box.addView(header)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun addToggle(label: String, detail: String) {
            val button = Button(this).apply {
                text = "$label: OFF"
                textSize = 11f
                setOnClickListener {
                    val on = text.toString().endsWith("OFF")
                    text = "$label: ${if (on) "ON" else "OFF"}"
                    setTextColor(if (on) 0xFFFF7078.toInt() else 0xFFFFFFFF.toInt())
                }
            }
            val caption = TextView(this).apply {
                text = detail
                textSize = 9f
                setTextColor(0xFFBBBBBB.toInt())
            }
            body.addView(button)
            body.addView(caption)
        }
        addToggle("Treino de mira", "Atalho visual; não controla o jogo")
        addToggle("Antena demo", "Indicador ilustrativo; não localiza jogadores")
        addToggle("Monitor", "Estado local do painel")
        val collapse = Button(this).apply {
            text = "RECOLHER / EXPANDIR"
            textSize = 10f
            setOnClickListener {
                collapsed = !collapsed
                if (collapsed) {
                    box.removeView(body)
                    text = "EXPANDIR"
                } else {
                    box.addView(body, 1)
                    text = "RECOLHER"
                }
            }
        }
        box.addView(body)
        box.addView(collapse)
        val close = Button(this).apply {
            text = "FECHAR PAINEL"
            textSize = 10f
            setOnClickListener { stopSelf() }
        }
        box.addView(close)
        panel = box
        wm.addView(box, params())
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            val p = panel?.layoutParams as? WindowManager.LayoutParams ?: return false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x; startY = p.y
                    touchX = event.rawX; touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX - (event.rawX - touchX).toInt()
                    p.y = startY + (event.rawY - touchY).toInt()
                    wm.updateViewLayout(panel, p)
                    return true
                }
            }
            return event.action == MotionEvent.ACTION_UP
        }
    }

    override fun onDestroy() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
