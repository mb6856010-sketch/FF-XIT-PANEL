package com.example.ffxitpanel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(0xFF101010.toInt())
        }
        val title = TextView(this).apply {
            text = "FF XIT PANEL"
            textSize = 27f
            setTextColor(0xFFFF454F.toInt())
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Painel flutuante demonstrativo\nControles locais, sem interação com o Free Fire."
            textSize = 15f
            setTextColor(0xFFEAEAEA.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(20))
        }
        val start = Button(this).apply {
            text = "ATIVAR PAINEL FLUTUANTE"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    val service = Intent(this@MainActivity, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service)
                    else startService(service)
                    finish()
                }
            }
        }
        val stop = Button(this).apply {
            text = "FECHAR PAINEL"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        layout.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(60)))
        layout.addView(info)
        layout.addView(start, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        layout.addView(stop, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)))
        setContentView(layout)
    }
}
